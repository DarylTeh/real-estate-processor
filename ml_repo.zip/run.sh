#!/bin/sh

# Run the Streamlit app 
python3 -m streamlit run 1_UniSum.py


# Cloud9 Preview
#python3 -m streamlit run 1_UniSum_Health.py --server.port 8080

